﻿using System.Web.Mvc;

namespace HeadHunter2.Controllers
{
    public class CompanyController : Controller
    {
        // GET
        public ActionResult Index()
        {
            return View();
        }
    }
}