﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HeadHunter2.Models;
using HeadHunter2.ViewModels;

namespace HeadHunter2.Controllers
{
    public class JobExperienceController : Controller
    {
        private ApplicationDbContext _context;

        public JobExperienceController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ActionResult Edit(int jobExperienceId)
        {
            var jobExperience = _context.JobExperiences.SingleOrDefault(item => item.Id == jobExperienceId);
            if (jobExperience == null)
            {
                return HttpNotFound();
            }

            return View(jobExperience);
        }

        [HttpPost]
        public ActionResult Edit(JobExperience jobExperience)
        {
            var jobExperienceFromDb = _context.JobExperiences.SingleOrDefault(item => item.Id == jobExperience.Id);
            if (jobExperienceFromDb == null)
            {
                return HttpNotFound();
            }

            jobExperienceFromDb.BeginDate = jobExperience.BeginDate;
            jobExperienceFromDb.CompanyName = jobExperience.CompanyName;
            jobExperienceFromDb.EndDate = jobExperience.EndDate;
            jobExperienceFromDb.Position = jobExperience.Position;
            jobExperienceFromDb.IsActive = jobExperience.IsActive;

            _context.SaveChanges();

            return RedirectToAction("Edit", "CV", new { Id = jobExperience.CvId });
        }

        public ActionResult Delete(int jobExperienceId)
        {
            var jobExperience = _context.JobExperiences.SingleOrDefault(item => item.Id == jobExperienceId);
            if (jobExperience == null)
            {
                return HttpNotFound();
            }

            _context.JobExperiences.Remove(jobExperience);
            _context.SaveChanges();

            return RedirectToAction("Edit", "CV", new { Id = jobExperienceId});
        }

        public ActionResult New(int cvId)
        {
            var cv = _context.CVs.SingleOrDefault(item => item.Id == cvId);

            if (cv == null)
            {
                return HttpNotFound();
            }

            return View(cv);
        }

        public ActionResult Create(string companyName, DateTime beginDate, DateTime endDate, bool? isActive, string position, int cvId)
        {
            var cv = _context.CVs.SingleOrDefault(item => item.Id == cvId);
            if (cv == null)
            {
                return HttpNotFound();
            }

            isActive = isActive != null;
            var jobExperience = new JobExperience
            {
                CvId = cvId,
                CompanyName = companyName,
                BeginDate = beginDate,
                EndDate = endDate,
                IsActive = (bool) isActive,
                Position = position
            };

            _context.JobExperiences.Add(jobExperience);
            _context.SaveChanges();

            return RedirectToAction("Edit", "CV", new { Id = cvId });
        }
    }
}