﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Dynamic;
using System.Linq;
using System.Web;

namespace HeadHunter2.Models
{
    public class JobExperience
    {
        public int Id { get; set; }

        public int CvId { get; set; }

        public string CompanyName { get; set; }

        [DisplayFormat(DataFormatString = "{0:MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime BeginDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }

        public bool IsActive { get; set; }

        public string Position { get; set; }

        public CV Cv { get; set; }

        public string CountDuration()
        {
            DateTime end;
            if (EndDate == null)
            {
                end = DateTime.Now;
            }
            else
            {
                end = (DateTime) EndDate;
            }

            var result = end.Subtract(BeginDate).TotalDays;
            if (result > 365)
            {
                return (result / 365).ToString() + " years";
            }
            else
            {
                return (result / 30).ToString() + " months";
            }
        }
    }
}