﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace HeadHunter2.Models
{
    public class Education
    {
        public int Id { get; set; }

        public int CvId { get; set; }

        public string Level { get; set; }

        public string Place { get; set; }

        public string Faculty { get; set; }

        public string Speciality { get; set; }

        [Range(0, 9999)]
        public int YearOfCompletion { get; set; }

        public CV Cv { get; set; }
    }
}