﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;

namespace HeadHunter2.ViewModels
{
    public class CVProfessionalFieldFormModel
    {
        public int CvId { get; set; }

        public int ProfessionalFieldId { get; set; }
    }
}