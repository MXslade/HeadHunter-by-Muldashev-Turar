﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HeadHunter2.Models;

namespace HeadHunter2.ViewModels
{
    public class CvEducationModelView
    {
        public CV Cv { get; set; }

        public Education Education { get; set; }
    }
}